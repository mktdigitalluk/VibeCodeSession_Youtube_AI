import json, logging, random, re
from google import genai
from config import Config
logger = logging.getLogger(__name__)

ENVIRONMENTS = [
    "a rainy night apartment with neon reflections on the window and city buildings behind",
    "a futuristic cyberpunk high-rise with dense skyscrapers in the background",
    "a mountain cabin workspace with snow outside and a valley view",
    "a cozy dark home office with panoramic urban buildings in the distance",
    "a late-night startup office overlooking a modern skyline",
]

SYSTEM_PROMPT = '''
You are planning a faceless YouTube video for a channel called Vibe Coding Sessions.
Output strict JSON only with these fields:
theme, title, music_prompt, visual_prompt, description, tags, duration_minutes
Rules:
- The image must always show a software developer working on a laptop with code visible.
- Vary the environment, weather, time, and landscape.
- No text in the image.
- Music must be instrumental only, no vocals, no lyrics.
- duration_minutes must be an integer.
'''

def _fallback_idea(history):
    env = random.choice(ENVIRONMENTS)
    return {
        "theme": "Vibe Coding Session",
        "title": f"Deep Focus Coding Music | {env.split(' with ')[0].title()}"[:95],
        "music_prompt": "Minimal ambient electronic music for deep coding focus, instrumental only, no vocals, calm immersive atmosphere, slow evolving synth pads, ideal for late night programming.",
        "visual_prompt": f"A software developer working on a laptop with code visible on screen, in {env}, cinematic lighting, atmospheric, immersive, high quality digital illustration, no text.",
        "description": "Ambient coding music for developers, makers, and deep work sessions.",
        "tags": ["coding music", "focus music", "programming", "deep work", "ambient"],
        "duration_minutes": Config.video_duration_minutes,
    }

def _extract_json(text):
    cleaned = text.strip()
    cleaned = re.sub(r"^```json\s*", "", cleaned)
    cleaned = re.sub(r"```$", "", cleaned).strip()
    return json.loads(cleaned)

def generate_video_idea(history):
    if not Config.gemini_api_key:
        return _fallback_idea(history)
    try:
        client = genai.Client(api_key=Config.gemini_api_key)
        response = client.models.generate_content(
            model=Config.gemini_text_model,
            contents=[
                {"role": "user", "parts": [{"text": SYSTEM_PROMPT}]},
                {"role": "user", "parts": [{"text": json.dumps({"recent_videos": history[-10:], "allowed_environments": ENVIRONMENTS, "duration_minutes": Config.video_duration_minutes}, ensure_ascii=False)}]},
            ],
        )
        idea = _extract_json(response.text)
        idea["duration_minutes"] = int(idea.get("duration_minutes") or Config.video_duration_minutes)
        if not isinstance(idea.get("tags"), list):
            idea["tags"] = ["coding music", "focus music", "programming", "deep work", "ambient"]
        return idea
    except Exception as exc:
        logger.warning("Gemini idea generation failed, using fallback: %s", exc)
        return _fallback_idea(history)
