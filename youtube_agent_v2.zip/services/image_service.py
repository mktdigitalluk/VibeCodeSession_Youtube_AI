from pathlib import Path
import logging
from urllib.parse import quote
import requests
from PIL import Image, ImageDraw
from google import genai
from google.genai import types
from config import Config

logger = logging.getLogger(__name__)

def _fallback_local(output_path: Path, title: str) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGB", (2048, 1152), (13, 18, 32))
    draw = ImageDraw.Draw(img)
    for idx, h in enumerate([220, 360, 180, 450, 310, 520, 240, 390, 280]):
        x = 120 + idx * 180
        draw.rectangle([x, 1152 - h, x + 110, 1152], fill=(26, 34, 60))
    draw.rectangle([0, 980, 2048, 1152], fill=(10, 14, 24))
    draw.text((70, 70), "Vibe Coding Sessions", fill=(180, 210, 255))
    draw.text((70, 130), title[:90], fill=(130, 170, 255))
    img.save(output_path)
    return output_path

def _pollinations(prompt: str, output_path: Path) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    url = f"https://image.pollinations.ai/prompt/{quote(prompt, safe='')}?width=2048&height=1152&nologo=true"
    r = requests.get(url, timeout=180)
    r.raise_for_status()
    output_path.write_bytes(r.content)
    return output_path

def _gemini(prompt: str, output_path: Path) -> Path:
    client = genai.Client(api_key=Config.gemini_api_key)
    response = client.models.generate_content(
        model=Config.gemini_image_model,
        contents=[prompt],
        config=types.GenerateContentConfig(
            response_modalities=["IMAGE"],
            image_config=types.ImageConfig(aspect_ratio="16:9", image_size="2K"),
        ),
    )
    candidates = getattr(response, "candidates", None) or []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        parts = getattr(content, "parts", None) or []
        for part in parts:
            if hasattr(part, "as_image"):
                part.as_image().save(output_path)
                return output_path
            inline_data = getattr(part, "inline_data", None)
            if inline_data and getattr(inline_data, "data", None):
                raw = inline_data.data
                if isinstance(raw, str):
                    import base64
                    raw = base64.b64decode(raw)
                output_path.write_bytes(raw)
                return output_path
    raise RuntimeError("No image returned by Gemini")

def generate_thumbnail(prompt: str, output_path: Path, title: str) -> Path:
    provider = Config.thumbnail_provider.lower().strip()
    try:
        if provider == "gemini":
            return _gemini(prompt, output_path)
        if provider == "pollinations":
            return _pollinations(prompt, output_path)
        return _fallback_local(output_path, title)
    except Exception as exc:
        logger.warning("Thumbnail provider '%s' failed, using local fallback: %s", provider, exc)
        return _fallback_local(output_path, title)
